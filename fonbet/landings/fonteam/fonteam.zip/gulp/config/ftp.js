// FTP settings
export const configFTP = {
  host: "", // FTP adress
  user: "", // login
  password: "", // password
  parallel: 5, // number of concurrent threads
};
