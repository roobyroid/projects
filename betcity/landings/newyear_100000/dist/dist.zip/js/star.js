/* eslint-disable no-var */
(function (cjs, an) {

  var p; // shortcut to reference prototypes
  var lib = {}; var ss = {}; var img = {};
  lib.ssMetadata = [
    {name: 'star_atlas_1', frames: [[0, 0, 728, 741]]}
  ];


  (lib.AnMovieClip = function () {
    this.actionFrames = [];
    this.ignorePause = false;
    this.gotoAndPlay = function (positionOrLabel) {
      cjs.MovieClip.prototype.gotoAndPlay.call(this, positionOrLabel);
    };
    this.play = function () {
      cjs.MovieClip.prototype.play.call(this);
    };
    this.gotoAndStop = function (positionOrLabel) {
      cjs.MovieClip.prototype.gotoAndStop.call(this, positionOrLabel);
    };
    this.stop = function () {
      cjs.MovieClip.prototype.stop.call(this);
    };
  }).prototype = p = new cjs.MovieClip();
  // symbols:


  (lib.shutterstock_2257309713 = function () {
    this.initialize(ss['star_atlas_1']);
    this.gotoAndStop(0);
  }).prototype = p = new cjs.Sprite();
  // helper functions:

  function mc_symbol_clone() {
    var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop, this.reversed));
    clone.gotoAndStop(this.currentFrame);
    clone.paused = this.paused;
    clone.framerate = this.framerate;
    return clone;
  }

  function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
    var prototype = cjs.extend(symbol, cjs.MovieClip);
    prototype.clone = mc_symbol_clone;
    prototype.nominalBounds = nominalBounds;
    prototype.frameBounds = frameBounds;
    return prototype;
  }


  (lib.Symbol1 = function (mode, startPosition, loop, reversed) {
    if (loop == null) {
      loop = true;
    }
    if (reversed == null) {
      reversed = false;
    }
    var props = new Object();
    props.mode = mode;
    props.startPosition = startPosition;
    props.labels = {};
    props.loop = loop;
    props.reversed = reversed;
    cjs.MovieClip.apply(this, [props]);

    // Layer_1
    this.shape = new cjs.Shape();
    this.shape.graphics.rf(['#FFFFFF', 'rgba(255,255,255,0)'], [0, 1], 0.1, 0, 0, 0.1, 0, 92.7).s().p('AGmHyQjOivkNkNQkNkNivjOQivjOAWgWQAXgXDOCvQDPCvELENQEPEMCuDPQCuDOgVAXQgDACgFAAQgmAAi3ibg');
    this.shape.setTransform(65.3201, 65.2944);

    this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

    this._renderFirstFrame();

  }).prototype = getMCSymbolPrototype(lib.Symbol1, new cjs.Rectangle(0, 0, 130.7, 130.6), null);


  (lib.LIGHT = function (mode, startPosition, loop, reversed) {
    if (loop == null) {
      loop = true;
    }
    if (reversed == null) {
      reversed = false;
    }
    var props = new Object();
    props.mode = mode;
    props.startPosition = startPosition;
    props.labels = {};
    props.loop = loop;
    props.reversed = reversed;
    cjs.MovieClip.apply(this, [props]);

    // Layer_2
    this.shape = new cjs.Shape();
    this.shape.graphics.rf(['#FFFFFF', 'rgba(255,255,255,0)'], [0, 1], 0, 0, 0, 0, 0, 88.9).s().p('ApuJwQkCkCAAluQAAlsECkDQEBkBFtAAQFtAAECEBQECEDAAFsQAAFukCECQkCEBltAAQltAAkBkBg');
    this.shape.setTransform(87.5, 88.1);

    this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

    this._renderFirstFrame();

  }).prototype = getMCSymbolPrototype(lib.LIGHT, new cjs.Rectangle(-0.6, 0, 176.2, 176.2), null);


  (lib.G11 = function (mode, startPosition, loop, reversed) {
    if (loop == null) {
      loop = true;
    }
    if (reversed == null) {
      reversed = false;
    }
    var props = new Object();
    props.mode = mode;
    props.startPosition = startPosition;
    props.labels = {};
    props.loop = loop;
    props.reversed = reversed;
    cjs.MovieClip.apply(this, [props]);

    // Layer_3_copy
    this.shape = new cjs.Shape();
    this.shape.graphics.rf(['#FFFFFF', 'rgba(255,255,255,0)'], [0, 1], 0, 0, 0, 0, 0, 70.2).s().p('AnrHsQjMjLAAkhQAAkfDMjMQDLjMEgAAQEgAADMDMQDMDMAAEfQAAEhjMDLQjMDMkgAAQkgAAjLjMg');
    this.shape.setTransform(189.275, 188.425);

    this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

    // Layer_3
    this.shape_1 = new cjs.Shape();
    this.shape_1.graphics.rf(['#FFFFFF', 'rgba(255,255,255,0)'], [0, 1], 0, 0, 0, 0, 0, 139).s().p('AvNPPQmUmTAAo8QAAo6GUmUQGTmTI6AAQI7AAGTGTQGUGUAAI6QAAI8mUGTQmTGTo7AAQo6AAmTmTg');
    this.shape_1.setTransform(189.275, 188.425);

    this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

    // Layer_3_copy_copy_copy_copy_copy
    this.instance = new lib.Symbol1();
    this.instance.setTransform(181.1, 189.2, 1.1488, 1.169, 60.0007, 0, 0, 65.3, 65.3);
    this.instance.alpha = 0.3594;

    this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

    // Layer_3_copy_copy_copy_copy
    this.instance_1 = new lib.Symbol1();
    this.instance_1.setTransform(180.75, 189.1, 1.6689, 1.4689, -75.0001, 0, 0, 65.2, 65.3);
    this.instance_1.alpha = 0.3008;

    this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

    // Layer_3_copy_copy_copy
    this.instance_2 = new lib.Symbol1();
    this.instance_2.setTransform(180.85, 189.05, 1, 1, 0, 0, 0, 65.3, 65.3);
    this.instance_2.alpha = 0.3086;

    this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(1));

    this._renderFirstFrame();

  }).prototype = getMCSymbolPrototype(lib.G11, new cjs.Rectangle(0, 0, 352, 382), null);


  (lib.STAAR = function (mode, startPosition, loop, reversed) {
    if (loop == null) {
      loop = true;
    }
    if (reversed == null) {
      reversed = false;
    }
    var props = new Object();
    props.mode = mode;
    props.startPosition = startPosition;
    props.labels = {};
    props.loop = loop;
    props.reversed = reversed;
    cjs.MovieClip.apply(this, [props]);

    // Layer_1_copy_copy_copy
    this.instance = new lib.LIGHT();
    this.instance.setTransform(49.6, 123.4, 0.1628, 0.1628, 0, 0, 0, 88.2, 87.9);
    this.instance.alpha = 0;
    this.instance.compositeOperation = 'screen';
    this.instance._off = true;

    this.timeline.addTween(cjs.Tween.get(this.instance).wait(26).to({_off: false}, 0).to({alpha: 1}, 9).to({alpha: 0}, 10).wait(6));

    // Layer_1_copy_copy
    this.instance_1 = new lib.LIGHT();
    this.instance_1.setTransform(93.05, 158.35, 0.2687, 0.2687, 0, 0, 0, 87.8, 87.8);
    this.instance_1.alpha = 0;
    this.instance_1.compositeOperation = 'screen';
    this.instance_1._off = true;

    this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(11).to({_off: false}, 0).to({alpha: 1}, 9).to({alpha: 0}, 10).wait(21));

    // Layer_1_copy
    this.instance_2 = new lib.LIGHT();
    this.instance_2.setTransform(110.05, 6.55, 0.2687, 0.2687, 0, 0, 0, 87.8, 87.8);
    this.instance_2.alpha = 0;
    this.instance_2.compositeOperation = 'screen';
    this.instance_2._off = true;

    this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(19).to({_off: false}, 0).to({alpha: 1}, 9).to({alpha: 0}, 10).wait(13));

    // Layer_1
    this.instance_3 = new lib.LIGHT();
    this.instance_3.setTransform(29.5, 29.5, 0.2687, 0.2687, 0, 0, 0, 87.8, 87.8);
    this.instance_3.alpha = 0;
    this.instance_3.compositeOperation = 'screen';
    this.instance_3._off = true;

    this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(5).to({_off: false}, 0).to({alpha: 1}, 9).to({alpha: 0}, 10).wait(27));

    // Layer_1_copy
    this.instance_4 = new lib.G11();
    this.instance_4.setTransform(176.3, 65.15, 0.0642, 0.0642, 0, 0, 0, 176.1, 191.7);
    this.instance_4.alpha = 0;
    this.instance_4.compositeOperation = 'screen';
    this.instance_4._off = true;

    this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(21).to({_off: false}, 0).to({regY: 191.2, scaleX: 0.1525, scaleY: 0.1525, x: 174.75, alpha: 1}, 14).to({scaleX: 0.0795, scaleY: 0.0795, alpha: 0}, 15).wait(1));

    // Layer_1
    this.instance_5 = new lib.G11();
    this.instance_5.setTransform(18.85, 84.65, 0.0642, 0.0642, 0, 0, 0, 176.1, 191.7);
    this.instance_5.alpha = 0;
    this.instance_5.compositeOperation = 'screen';

    this.timeline.addTween(cjs.Tween.get(this.instance_5).to({regY: 191.2, scaleX: 0.1525, scaleY: 0.1525, x: 17.3, alpha: 1}, 14).to({scaleX: 0.0795, scaleY: 0.0795, alpha: 0}, 15).wait(22));

    // Layer_1
    this.instance_6 = new lib.shutterstock_2257309713();
    this.instance_6.setTransform(-1, 0, 0.2441, 0.2441);

    this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(51));

    this._renderFirstFrame();

  }).prototype = p = new cjs.MovieClip();
  p.nominalBounds = new cjs.Rectangle(-1.7, -17, 199.5, 199.1);


  // stage content:
  (lib.star = function (mode, startPosition, loop, reversed) {
    if (loop == null) {
      loop = true;
    }
    if (reversed == null) {
      reversed = false;
    }
    var props = new Object();
    props.mode = mode;
    props.startPosition = startPosition;
    props.labels = {};
    props.loop = loop;
    props.reversed = reversed;
    cjs.MovieClip.apply(this, [props]);

    // Layer_1
    this.instance = new lib.STAAR();
    this.instance.setTransform(253.95, 252.05, 2.3072, 2.3072, 0, 0, 0, 88.8, 90.4);

    this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

    // stageBackground
    this.shape = new cjs.Shape();
    this.shape.graphics.f().s('rgba(0,0,0,0)').ss(1, 1, 1, 3, true).p('EgpFgpFMBSLAAAMAAABSLMhSLAAAg');
    this.shape.setTransform(253, 253);

    this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

    this._renderFirstFrame();

  }).prototype = p = new lib.AnMovieClip();
  p.nominalBounds = new cjs.Rectangle(299.8, 296.5, 157, 164.39999999999998);
  // library properties:
  lib.properties = {
    id: '9CF9F763DF48B74799E8DB9793799DAF',
    width: 506,
    height: 506,
    fps: 30,
    color: '#000000',
    opacity: 0.00,
    manifest: [
      {src: 'img/page/star_atlas_1.png', id: 'star_atlas_1'}
    ],
    preloads: [],
  };


  // bootstrap callback support:

  (lib.Stage = function (canvas) {
    createjs.Stage.call(this, canvas);
  }).prototype = p = new createjs.Stage();

  p.setAutoPlay = function (autoPlay) {
    this.tickEnabled = autoPlay;
  };
  p.play = function () {
    this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition());
  };
  p.stop = function (ms) {
    if (ms) {
      this.seek(ms);
    } this.tickEnabled = false;
  };
  p.seek = function (ms) {
    this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000);
  };
  p.getDuration = function () {
    return this.getChildAt(0).totalFrames / lib.properties.fps * 1000;
  };

  p.getTimelinePosition = function () {
    return this.getChildAt(0).currentFrame / lib.properties.fps * 1000;
  };

  an.bootcompsLoaded = an.bootcompsLoaded || [];
  if (!an.bootstrapListeners) {
    an.bootstrapListeners = [];
  }

  an.bootstrapCallback = function (fnCallback) {
    an.bootstrapListeners.push(fnCallback);
    if (an.bootcompsLoaded.length > 0) {
      for (var i = 0; i < an.bootcompsLoaded.length; ++i) {
        fnCallback(an.bootcompsLoaded[i]);
      }
    }
  };

  an.compositions = an.compositions || {};
  an.compositions['9CF9F763DF48B74799E8DB9793799DAF'] = {
    getStage() {
      return exportRoot.stage;
    },
    getLibrary() {
      return lib;
    },
    getSpriteSheet() {
      return ss;
    },
    getImages() {
      return img;
    },
  };

  an.compositionLoaded = function (id) {
    an.bootcompsLoaded.push(id);
    for (var j = 0; j < an.bootstrapListeners.length; j++) {
      an.bootstrapListeners[j](id);
    }
  };

  an.getComposition = function (id) {
    return an.compositions[id];
  };


  an.makeResponsive = function (isResp, respDim, isScale, scaleType, domContainers) {
    var lastW; var lastH; var lastS = 1;
    window.addEventListener('resize', resizeCanvas);
    resizeCanvas();
    function resizeCanvas() {
      var w = lib.properties.width; var h = lib.properties.height;
      var iw = window.innerWidth; var ih = window.innerHeight;
      var pRatio = window.devicePixelRatio || 1; var xRatio = iw / w; var yRatio = ih / h; var sRatio = 1;
      if (isResp) {
        if ((respDim == 'width' && lastW == iw) || (respDim == 'height' && lastH == ih)) {
          sRatio = lastS;
        } else if (!isScale) {
          if (iw < w || ih < h) {
            sRatio = Math.min(xRatio, yRatio);
          }
        } else if (scaleType == 1) {
          sRatio = Math.min(xRatio, yRatio);
        } else if (scaleType == 2) {
          sRatio = Math.max(xRatio, yRatio);
        }
      }
      domContainers[0].width = w * pRatio * sRatio;
      domContainers[0].height = h * pRatio * sRatio;
      domContainers.forEach(function (container) {
        container.style.width = w * sRatio + 'px';
        container.style.height = h * sRatio + 'px';
      });
      stage.scaleX = pRatio * sRatio;
      stage.scaleY = pRatio * sRatio;
      lastW = iw; lastH = ih; lastS = sRatio;
      stage.tickOnUpdate = false;
      stage.update();
      stage.tickOnUpdate = true;
    }
  };
  an.handleSoundStreamOnTick = function (event) {
    if (!event.paused) {
      var stageChild = stage.getChildAt(0);
      if (!stageChild.paused || stageChild.ignorePause) {
        stageChild.syncStreamSounds();
      }
    }
  };
  an.handleFilterCache = function (event) {
    if (!event.paused) {
      var target = event.target;
      if (target) {
        if (target.filterCacheList) {
          for (var index = 0; index < target.filterCacheList.length; index++) {
            var cacheInst = target.filterCacheList[index];
            if ((cacheInst.startFrame <= target.currentFrame) && (target.currentFrame <= cacheInst.endFrame)) {
              cacheInst.instance.cache(cacheInst.x, cacheInst.y, cacheInst.w, cacheInst.h);
            }
          }
        }
      }
    }
  };


})(createjs = createjs || {}, AdobeAn = AdobeAn || {});
var createjs; var AdobeAn;
